// Polybius Square Encoding Table
const polybiusTable = {
    "A": "11", "B": "12", "C": "13", "D": "14", "E": "15", 
    "F": "21", "G": "22", "H": "23", "I": "24", "J": "25", 
    "K": "31", "L": "32", "M": "33", "N": "34", "O": "35", 
    "P": "41", "Q": "42", "R": "43", "S": "44", "T": "45", 
    "U": "51", "V": "52", "W": "53", "X": "54", "Y": "55", 
    "Z": "00"
};

// Inverse Table for Decoding
const inverseTable = {};
for (let key in polybiusTable) {
    inverseTable[polybiusTable[key]] = key;
}

// Function to encode text using Polybius Square
function encodeText(text) {
    text = text.toUpperCase();
    return text.split('').map(char => polybiusTable[char] || char).join(' ');
}

// Function to decode text using Polybius Square
function decodeText(text) {
    return text.split(' ').map(code => inverseTable[code] || code).join('');
}

// Function to handle encoding/decoding based on user input
function startProcess() {
    let mode = parseInt(prompt("Select mode:\n0 - Encoding\n1 - Decoding"),10);
    let text = prompt("Enter your text:");

    let result = (mode === 0) ? encodeText(text) : decodeText(text);
    alert(`Result:\n${result}`);
}

// Run the function
startProcess();
