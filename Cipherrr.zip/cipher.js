// Function to generate a repeating key for Vigenere Cipher
function generateKey(string, key) { 
    key = key.toUpperCase(); 
    let generatedKey = ''; 
    for (let i = 0; i < string.length; i++) { 
        generatedKey += key[i % key.length]; 
    } 
    return generatedKey; 
} 

// Function to encrypt plaintext using Vigenere Cipher
function vigenereEncrypt(plaintext, key) { 
    plaintext = plaintext.toUpperCase(); 
    let encryptedText = ''; 
    for (let i = 0; i < plaintext.length; i++) { 
        let charCode = plaintext.charCodeAt(i); 
        if (charCode >= 65 && charCode <= 90) { // A-Z
            let shift = key.charCodeAt(i) - 65; 
            let encryptedCharCode = ((charCode - 65 + shift) % 26) + 65; 
            encryptedText += String.fromCharCode(encryptedCharCode); 
        } else { 
            encryptedText += plaintext[i]; // Leave special characters unchanged
        } 
    } 
    return encryptedText; 
} 

// Function to decrypt ciphertext using Vigenere Cipher
function vigenereDecrypt(ciphertext, key) { 
    ciphertext = ciphertext.toUpperCase(); 
    let decryptedText = ''; 
    for (let i = 0; i < ciphertext.length; i++) { 
        let charCode = ciphertext.charCodeAt(i); 
        if (charCode >= 65 && charCode <= 90) { // A-Z
            let shift = key.charCodeAt(i) - 65; 
            let decryptedCharCode = ((charCode - 65 - shift + 26) % 26) + 65; 
            decryptedText += String.fromCharCode(decryptedCharCode); 
        } else { 
            decryptedText += ciphertext[i]; // Leave special characters unchanged
        } 
    } 
    return decryptedText; 
} 

// Event listener for Encrypt button
document.getElementById('encrypt-btn').addEventListener('click', function() { 
    let plaintext = document.getElementById('plaintext').value.trim(); 
    let keyword = document.getElementById('keyword').value.trim(); 

    if (plaintext === "" || keyword === "") { 
        alert("Please enter both plaintext and keyword!"); 
        return; 
    }

    let key = generateKey(plaintext, keyword); 
    let encryptedText = vigenereEncrypt(plaintext, key); 

    document.getElementById('output').innerHTML =` <strong>Encrypted Text:</strong> ${encryptedText};`
}); 

// Event listener for Decrypt button
document.getElementById('decrypt-btn').addEventListener('click', function() { 
    let ciphertext = document.getElementById('ciphertext').value.trim(); 
    let keyword = document.getElementById('keyword').value.trim(); 

    if (ciphertext === "" || keyword === "") { 
        alert("Please enter both ciphertext and keyword!"); 
        return; 
    }

    let key = generateKey(ciphertext, keyword); 
    let decryptedText = vigenereDecrypt(ciphertext, key); 

    document.getElementById('output').innerHTML = `<strong>Decrypted Text:</strong> ${decryptedText};`
}); 

// Event listener for Continue button
document.getElementById('continue-btn').addEventListener('click', function() { 
    window.location.href = "part_b.html"; // Navigate to Part B 
});
